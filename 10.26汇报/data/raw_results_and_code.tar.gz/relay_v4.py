# -*- coding: utf-8 -*-
"""Threaded, deterministic qwen-plus relay with per-call usage logging.
Usage: python3 relay_t.py <port>"""
import json, os, sys, threading, time, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

KEY_PATH = "/home/orange/.dashscope_key"
API = "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions"
MODEL = os.getenv("MAPGPT_MODEL", "qwen-plus")
LOG_PATH = os.getenv("MAPGPT_RELAY_LOG", "/home/orange/relay_v4.jsonl")
_log_lock = threading.Lock()


def call_llm(prompt):
    key = open(KEY_PATH).read().strip()
    body = json.dumps({"model": MODEL,
                       "messages": [{"role": "user", "content": prompt}],
                       "temperature": 0.0,
                       "max_tokens": 700}).encode()
    req = urllib.request.Request(API, data=body, headers={
        "Authorization": "Bearer " + key, "Content-Type": "application/json"})
    r = urllib.request.urlopen(req, timeout=180)
    obj = json.loads(r.read().decode())
    content = obj["choices"][0]["message"]["content"]
    meta = {
        "request_id": r.headers.get("X-DashScope-Request-Id")
        or r.headers.get("X-Request-Id") or "",
        "model": obj.get("model", MODEL),
        "usage": obj.get("usage", {}),
        "created": obj.get("created"),
    }
    with _log_lock:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(meta, ensure_ascii=False) + "\n")
    return content, meta


class H(BaseHTTPRequestHandler):
    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        data = json.loads(self.rfile.read(n).decode())
        try:
            content, meta = call_llm(data["prompt"])
            payload = json.dumps({"result": content, **meta}).encode()
            code = 200
        except urllib.error.HTTPError as e:
            payload = json.dumps({"error": "HTTP %s %s" % (e.code, e.read().decode()[:300])}).encode()
            code = 500
        except Exception as e:
            payload = json.dumps({"error": "%s: %s" % (type(e).__name__, e)}).encode()
            code = 500
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5001
    print("relay_v4 listening on 127.0.0.1:%d model=%s" % (port, MODEL), flush=True)
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()
