# -*- coding: utf-8 -*-
"""Build the concise five-condition report, figures, data, and raw bundle."""
import base64
import csv
import json
import os
import random
import re
import shutil
import subprocess
import sys
import tarfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "vm_results"
OUT = ROOT.parent.parent / "outputs"
STAGE = ROOT.parent / "github_stage_5"
DATA = STAGE / "10.26汇报" / "data"
FIGS = STAGE / "10.26汇报" / "figs"

GROUPS = {
    "base": (["v4_obs5_base_a", "v4_obs5_base_b"], "5×5 基线"),
    "obs8": (["v4_obs8_a", "v4_obs8_b"], "8×8 观测"),
    "obs10": (["v4_obs10_a", "v4_obs10_b"], "10×10 观测"),
    "feedback": (["v4_scorefb_a", "v4_scorefb_b"], "评分反馈"),
    "res": (["v4_res2_obs10_a", "v4_res2_obs10_b"], "30×30 + 10×10"),
}
COLORS = {
    "base": "#1f2937",
    "obs8": "#0f766e",
    "obs10": "#2563eb",
    "feedback": "#7c3aed",
    "res": "#ea580c",
}


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def fnum(v, default=0.0):
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


def load():
    episodes, steps = {}, {}
    for key, (tags, _) in GROUPS.items():
        episodes[key] = []
        steps[key] = []
        for tag in tags:
            episodes[key].extend(read_csv(RAW / f"results_{tag}" / "episodes.csv"))
            steps[key].extend(read_csv(RAW / f"results_{tag}" / "steps.csv"))
        episodes[key].sort(key=lambda r: int(fnum(r["episode"])))
        steps[key].sort(key=lambda r: (int(fnum(r["episode"])), int(fnum(r["step"]))))
    return episodes, steps


def metrics(rows, step_rows):
    n = len(rows)
    total_steps = sum(int(fnum(r["steps"])) for r in rows)
    scale = fnum(rows[0]["res_scale"], 1) if rows else 1
    return {
        "N": n,
        "SR": mean(str(r["success"]).lower() == "true" for r in rows),
        "SPL": mean(
            (1.0 if str(r["success"]).lower() == "true" else 0.0)
            * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1)
            for r in rows
        ),
        "NE": mean(fnum(r["ne"]) for r in rows),
        "NE_physical": mean(fnum(r["ne"]) for r in rows) / scale,
        "ER": mean(
            fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1)
            for r in rows
        ),
        "AP": mean(fnum(r["ap"]) for r in rows),
        "DS": mean(fnum(r["ds_mean"]) for r in rows),
        "COV": mean(fnum(r["coverage"]) for r in rows),
        "STK": sum(int(fnum(r["stuck_steps"])) for r in rows) / total_steps,
        "GRD": sum(int(fnum(r["guard_count"])) for r in rows),
        "STOPREJ": sum(int(fnum(r["stop_rejected"])) for r in rows),
        "steps": total_steps / n,
        "calls": sum(int(fnum(r["llm_calls"])) for r in rows),
        "calls_ep": sum(int(fnum(r["llm_calls"])) for r in rows) / n,
        "P": mean(fnum(r["P"]) for r in step_rows),
        "V": mean(fnum(r["V"]) for r in step_rows),
        "M": mean(fnum(r["M"]) for r in step_rows),
        "C": mean(fnum(r["C"]) for r in step_rows),
        "G": mean(fnum(r["G"]) for r in step_rows),
    }


def per_ep(rows):
    out = {}
    for r in rows:
        s = 1.0 if str(r["success"]).lower() == "true" else 0.0
        out[int(fnum(r["episode"]))] = {
            "SR": s,
            "SPL": s * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1),
            "ER": fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1),
            "NE": fnum(r["ne"]),
            "AP": fnum(r["ap"]),
            "DS": fnum(r["ds_mean"]),
            "steps": fnum(r["steps"]),
        }
    return out


def paired_diff(base, other, metric):
    common = sorted(set(base) & set(other))
    d = [other[i][metric] - base[i][metric] for i in common]
    rng = random.Random(20261027)
    boots = sorted(mean(d[rng.randrange(len(d))] for _ in d) for _ in range(16000))
    return mean(d), boots[int(0.025 * len(boots))], boots[int(0.975 * len(boots)) - 1]


def route_cells(step_rows, scale=1):
    pts = []
    for r in step_rows:
        p = r.get("pose_after", "").split(",")
        if len(p) < 2:
            continue
        xy = (float(p[0]) / scale, float(p[1]) / scale)
        if not pts or pts[-1] != xy:
            pts.append(xy)
    return pts


def fmt_pct(x):
    return f"{x * 100:.1f}%"


def fmt(x):
    return f"{x:.3f}"


def savefig(name):
    p = FIGS / name
    plt.savefig(p, dpi=190, bbox_inches="tight")
    plt.close()
    return p


def draw_observation(m):
    groups = ["base", "obs8", "obs10"]
    labels = [GROUPS[g][1] for g in groups]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    x = np.arange(3)
    width = 0.24
    for i, key in enumerate(("SR", "SPL", "DS")):
        axes[0].bar(
            x + (i - 1) * width,
            [m[g][key] for g in groups],
            width,
            label=key,
            color=["#64748b", "#0891b2", "#7c3aed"][i],
        )
    axes[0].set_xticks(x, labels)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Navigation metrics")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    axes[1].bar(x, [m[g]["steps"] for g in groups], color=[COLORS[g] for g in groups])
    axes[1].set_xticks(x, labels)
    axes[1].set_title("Average actions per episode")
    axes[1].set_ylabel("actions")
    axes[1].grid(axis="y", alpha=0.2)

    for g in groups:
        vals = [m[g].get("_ep", {}).get(i, float("nan")) for i in range(10)]
        axes[2].plot(range(10), vals, "o-", label=GROUPS[g][1], color=COLORS[g])
    axes[2].set_xticks(range(10), [f"{i:02d}" for i in range(10)])
    axes[2].set_ylim(0, 1.05)
    axes[2].set_title("Per-episode SPL")
    axes[2].legend(frameon=False, fontsize=8)
    axes[2].grid(alpha=0.2)
    fig.tight_layout()
    savefig("fig1_observation.png")


def draw_feedback(m, stats):
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    groups = ["base", "feedback"]
    labels = [GROUPS[g][1] for g in groups]
    x = np.arange(2)
    width = 0.24
    names = ["SR", "SPL", "DS"]
    for i, (name, color) in enumerate(zip(names, ("#64748b", "#0891b2", "#7c3aed"))):
        axes[0].bar(x + (i - 1) * width, [m[g][name] for g in groups], width,
                    label=name, color=color)
    axes[0].set_xticks(x, labels)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Baseline vs score feedback")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    keys = ["after_low_next_P_mean", "after_low_next_P_eq_1", "after_low_new_cell_rate"]
    names = ["Next P", "Next P=1", "New cell"]
    x = np.arange(3)
    axes[1].bar(x - 0.18, [stats["base"][k] for k in keys], 0.36, label="无反馈", color="#64748b")
    axes[1].bar(x + 0.18, [stats["feedback"][k] for k in keys], 0.36, label="有反馈", color="#7c3aed")
    axes[1].set_xticks(x, names)
    axes[1].set_ylim(0, 1.05)
    axes[1].set_title("Behavior after a low-scoring step")
    axes[1].legend(frameon=False)
    axes[1].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig2_feedback.png")


def draw_resolution(m):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    groups = ["base", "res"]
    labels = ["5×5 基线", "30×30 + 10×10"]
    x = np.arange(3)
    width = 0.34
    metrics_names = ["SR", "SPL", "ER"]
    for i, g in enumerate(groups):
        axes[0].bar(x + (i - 0.5) * width, [m[g][k] for k in metrics_names], width,
                    label=labels[i], color=COLORS[g])
    axes[0].set_xticks(x, metrics_names)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Scale-normalized navigation metrics")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    ne_physical = [m["base"]["NE"], m["res"]["NE"] / 2.0]
    axes[1].bar([0, 1], ne_physical, color=[COLORS["base"], COLORS["res"]])
    axes[1].set_xticks([0, 1], labels)
    axes[1].set_title("Physical navigation error")
    axes[1].set_ylabel("15×15-cell units")
    axes[1].grid(axis="y", alpha=0.2)

    axes[2].bar([0, 1], [m["base"]["steps"], m["res"]["steps"]], color=[COLORS["base"], COLORS["res"]])
    axes[2].set_xticks([0, 1], labels)
    axes[2].set_title("Operational cost (not a performance score)")
    axes[2].set_ylabel("model actions")
    axes[2].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig3_resolution.png")


def draw_maps(env_builder, ep_rows, step_rows):
    fig, axes = plt.subplots(5, 2, figsize=(9.5, 19))
    axes = axes.ravel()
    for ep in range(10):
        env = env_builder(ep)
        ax = axes[ep]
        ax.imshow(np.array(env.grid), cmap="Greys", origin="upper", alpha=0.35, vmin=0, vmax=2)
        for g in GROUPS:
            scale = 2 if g == "res" else 1
            rr = [r for r in step_rows[g] if int(fnum(r["episode"])) == ep]
            pts = route_cells(rr, scale)
            if pts:
                ax.plot([p[0] + 0.5 for p in pts], [p[1] + 0.5 for p in pts],
                        color=COLORS[g], lw=1.4, alpha=0.82)
        ax.scatter([env.start[0] + 0.5], [env.start[1] + 0.5], marker="o", s=36,
                   facecolor="#22c55e", edgecolor="black", zorder=5)
        ax.scatter([env.goal[0] + 0.5], [env.goal[1] + 0.5], marker="*", s=95,
                   facecolor="#facc15", edgecolor="black", zorder=5)
        er = next(r for r in ep_rows["base"] if int(fnum(r["episode"])) == ep)
        ax.set_title(f"ep{ep:02d}  l={er['shortest']}  start={er['start']}  goal={er['goal']}", fontsize=9)
        ax.set_xlim(0, 15)
        ax.set_ylim(15, 0)
        ax.set_xticks([])
        ax.set_yticks([])
    handles = [
        Line2D([0], [0], color=COLORS[g], lw=2, label=GROUPS[g][1])
        for g in GROUPS
    ]
    handles += [
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#22c55e", markeredgecolor="black",
               markersize=8, label="起点"),
        Line2D([0], [0], marker="*", color="none", markerfacecolor="#facc15", markeredgecolor="black",
               markersize=11, label="终点"),
    ]
    fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.995))
    fig.tight_layout(rect=(0, 0, 1, 0.975))
    savefig("fig4_maps.png")


def draw_step_scores(step_rows):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for g in GROUPS:
        by_step = defaultdict(list)
        for r in step_rows[g]:
            by_step[int(fnum(r["step"]))].append(fnum(r["DS"]))
        xs = sorted(by_step)
        ys = [mean(by_step[x]) for x in xs]
        axes[0].plot(xs, ys, lw=1.8, label=GROUPS[g][1], color=COLORS[g])
    axes[0].set_xlim(0, 60)
    axes[0].set_ylim(0.25, 1.0)
    axes[0].set_xlabel("Within-episode step index")
    axes[0].set_ylabel("Mean DS")
    axes[0].set_title("Step-level composite score")
    axes[0].grid(alpha=0.2)
    axes[0].legend(frameon=False, fontsize=8)

    keys = ["P", "V", "M", "C", "G"]
    x = np.arange(len(keys))
    width = 0.15
    for i, g in enumerate(GROUPS):
        m = {k: mean(fnum(r[k]) for r in step_rows[g]) for k in keys}
        axes[1].bar(x + (i - 2) * width, [m[k] for k in keys], width,
                    label=GROUPS[g][1], color=COLORS[g])
    axes[1].set_xticks(x, keys)
    axes[1].set_ylim(0, 1.05)
    axes[1].set_title("Mean step-score components")
    axes[1].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig5_step_scores.png")


def low_score_stats(step_rows):
    out = {}
    for g in ("base", "feedback"):
        by_ep = defaultdict(list)
        for r in step_rows[g]:
            by_ep[int(fnum(r["episode"]))].append(r)
        tr = []
        for rows in by_ep.values():
            rows.sort(key=lambda r: int(fnum(r["step"])))
            tr += [(fnum(a["DS"]), fnum(b["DS"]), fnum(b["P"]), fnum(b["V"]))
                   for a, b in zip(rows, rows[1:])]
        low = [x for x in tr if x[0] <= 0.75]
        out[g] = {
            "after_low_N": len(low),
            "after_low_next_P_mean": mean(x[2] for x in low),
            "after_low_next_P_eq_1": mean(1.0 if x[2] >= 0.999 else 0.0 for x in low),
            "after_low_new_cell_rate": mean(1.0 if x[3] >= 0.999 else 0.0 for x in low),
            "after_low_next_DS_delta": mean(x[1] - x[0] for x in low),
        }
    return out


def main():
    OUT.mkdir(exist_ok=True)
    for d in (DATA, FIGS):
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)
    episodes, steps = load()
    m = {g: metrics(episodes[g], steps[g]) for g in GROUPS}
    for g in GROUPS:
        m[g]["_ep"] = {i: per_ep(episodes[g])[i]["SPL"] for i in range(10)}
    effects = {
        g: {
            k: paired_diff(per_ep(episodes["base"]), per_ep(episodes[g]), k)
            for k in ("SR", "SPL", "NE", "AP", "DS", "ER", "steps")
        }
        for g in ("obs8", "obs10", "feedback", "res")
    }
    feedback_behavior = low_score_stats(steps)

    # Filtered data deliverables
    ep_fields = [
        "group", "episode", "seed", "grid", "obs_size", "res_scale", "score_feedback",
        "start", "goal", "success", "shortest_steps", "actual_forward_steps",
        "shortest_physical_units", "actual_forward_physical_units",
        "action_steps", "path_score_SPL", "ER_path_ratio", "NE", "NE_physical_units",
        "AP", "DS", "route_cells",
    ]
    ep_out = []
    for g in GROUPS:
        for r in episodes[g]:
            ep_i = int(fnum(r["episode"]))
            sr = 1.0 if str(r["success"]).lower() == "true" else 0.0
            pts = route_cells([x for x in steps[g] if int(fnum(x["episode"])) == ep_i],
                              2 if g == "res" else 1)
            ep_out.append({
                "group": GROUPS[g][1],
                "episode": ep_i,
                "seed": r["seed"],
                "grid": r["grid"],
                "obs_size": r["obs_size"],
                "res_scale": r["res_scale"],
                "score_feedback": GROUPS[g][1] if g == "feedback" else "none",
                "start": r["start"],
                "goal": r["goal"],
                "success": r["success"],
                "shortest_steps": r["shortest"],
                "actual_forward_steps": r["actual"],
                "shortest_physical_units": round(fnum(r["shortest"]) / int(fnum(r["res_scale"], 1)), 6),
                "actual_forward_physical_units": round(fnum(r["actual"]) / int(fnum(r["res_scale"], 1)), 6),
                "action_steps": r["steps"],
                "path_score_SPL": round(sr * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1), 6),
                "ER_path_ratio": round(fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1), 6),
                "NE": r["ne"],
                "NE_physical_units": round(fnum(r["ne"]) / int(fnum(r["res_scale"], 1)), 6),
                "AP": r["ap"],
                "DS": r["ds_mean"],
                "route_cells": " -> ".join(f"{x:g},{y:g}" for x, y in pts),
            })
    with open(DATA / "per_episode_path_scores.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=ep_fields)
        w.writeheader()
        w.writerows(ep_out)

    metric_fields = ["N", "SR", "SPL", "NE", "NE_physical", "ER", "AP", "DS", "COV", "STK", "GRD",
                     "STOPREJ", "steps", "calls", "calls_ep", "P", "V", "M", "C", "G"]
    with open(DATA / "condition_metrics.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["condition"] + metric_fields)
        w.writeheader()
        for g in GROUPS:
            w.writerow({"condition": GROUPS[g][1], **{k: m[g][k] for k in metric_fields}})

    step_fields = ["condition", "episode", "step", "action", "cell", "P", "V", "M", "C", "G", "DS", "source"]
    with open(DATA / "step_scores.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=step_fields)
        w.writeheader()
        for g in GROUPS:
            for r in steps[g]:
                w.writerow({"condition": GROUPS[g][1], **{k: r[k] for k in step_fields[1:]}})

    analysis = {
        "conditions": {g: GROUPS[g][1] for g in GROUPS},
        "metrics": {GROUPS[g][1]: {k: v for k, v in m[g].items() if k != "_ep"} for g in GROUPS},
        "paired_effects_vs_baseline": {GROUPS[g][1]: effects[g] for g in effects},
        "feedback_behavior": {GROUPS[g][1]: feedback_behavior[g] for g in feedback_behavior},
    }
    (DATA / "analysis.json").write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")

    # Figures
    draw_observation(m)
    draw_feedback(m, feedback_behavior)
    draw_resolution(m)

    from mapgpt_vm_demo_v4 import EPISODE_SEED_BASE
    from mapgpt_v4 import build_navigation_env
    draw_maps(lambda ep: build_navigation_env(15, 15, EPISODE_SEED_BASE + ep * 17, 1),
              episodes, steps)
    draw_step_scores(steps)
    subprocess.run([sys.executable, str(ROOT / "analyze_ap.py")],
                   cwd=ROOT, check=True, env=dict(os.environ))
    ap_agg = json.loads((DATA / "ap_analysis.json").read_text(encoding="utf-8"))
    analysis["ap_components"] = ap_agg
    (DATA / "analysis.json").write_text(
        json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    # Raw bundle: selected five result directories only, plus code.
    bundle_path = DATA / "raw_results_and_code.tar.gz"
    with tarfile.open(bundle_path, "w:gz") as tf:
        for key, (tags, _) in GROUPS.items():
            for tag in tags:
                tf.add(RAW / f"results_{tag}", arcname=f"results_{tag}")
        for name in ("mapgpt_v4.py", "mapgpt_vm_demo_v4.py", "run_matrix.py",
                     "relay_v4.py", "analyze_ap.py", "make_final5.py"):
            tf.add(ROOT / name, arcname=name)
        tf.add(RAW / "relay_v4.jsonl", arcname="relay_v4.jsonl")

    condition_rows = []
    for g in GROUPS:
        x = m[g]
        condition_rows.append(
            f"| {GROUPS[g][1]} | {fmt_pct(x['SR'])} | {fmt(x['SPL'])} | {fmt(x['NE'])} | "
            f"{fmt(x['AP'])} | {fmt(x['DS'])} | {fmt(x['STK'])} | {x['GRD']} | {x['steps']:.1f} |"
        )
    component_rows = []
    for g in GROUPS:
        x = m[g]
        component_rows.append(
            f"| {GROUPS[g][1]} | {fmt(x['P'])} | {fmt(x['V'])} | {fmt(x['M'])} | {fmt(x['C'])} | {fmt(x['G'])} |"
        )
    path_rows = []
    for g in GROUPS:
        vals = {i: per_ep(episodes[g])[i]["SPL"] for i in range(10)}
        path_rows.append(
            f"| {GROUPS[g][1]} | " + " | ".join(f"{vals[i]:.3f}" for i in range(10))
            + f" | {mean(vals.values()):.3f} |"
        )
    ap_rows = []
    for g in GROUPS:
        x = ap_agg[GROUPS[g][1]]
        ap_rows.append(
            f"| {GROUPS[g][1]} | {x['cell_acc']:.3f} | {x['edge_precision']:.3f} | "
            f"{x['edge_recall']:.3f} | {x['AP']:.3f} | {x['pred_edges']:.1f} | "
            f"{x['observed_edges']:.1f} |"
        )
    ne_res_phys = tuple(v / 2.0 for v in effects["res"]["NE"])

    def diff_text(g, metric):
        d, lo, hi = effects[g][metric]
        return f"{d:+.3f} [{lo:+.3f}, {hi:+.3f}]"

    report = f"""# MapGPT 文本网格导航三任务对比实验

实验基于 v3 的锚点、前沿路径、防卡死与 STOP 坐标门，使用 10 个固定种子和 qwen-plus。所有条件最大 100 步，比较对象均为 5×5 基线。

## 结果摘要

| 任务 | 对比 | 主要结果 | 结论 |
|---|---|---|---|
| 观测范围 | 8×8、10×10 | SPL 0.910、0.909，基线 0.894 | 8×8 点估计最好，10×10 无继续增益 |
| 评分反馈 | 上一步 DS/P/V/M/C/G | SPL 0.805，基线 0.894；平均步数 22.1 对 19.2 | 模型会改变行为，但未提升导航表现 |
| 地图分辨率 | 30×30 + 10×10 | SR 90%，SPL 0.780，物理 NE 0.75 | 公平路径指标下没有性能增益；调用成本增加 |

## 实验设置

- 15×15 地图十幅，种子为 `20240928 + 17i`。
- 动作空间为 `FORWARD/LEFT/RIGHT/STOP`，一次动作移动或转向一步。
- 局部观测以机器人为中心，墙体阻断视线。
- 所有调用使用 qwen-plus、`temperature=0`、`max_tokens=700`。
- 30×30 地图由同一 15×15 地图逐格放大为 2×2 小格，物理布局不变。
- `30×30 + 10×10` 保持与基线相同的物理视野；一次动作移动一个细格，约等于基线半个物理格。
- 每一步先输出动作，再输出最多 16 个关键地图格。
- 观测范围和评分反馈使用 SR、SPL、DS；分辨率对比使用 SR、SPL、ER 和换算后的物理 NE。
- 原始动作数只表示计算成本，不作为跨分辨率导航质量。

## 一、观测范围

| 条件 | SR | SPL | NE | AP | DS | STK | GRD | 步/局 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(condition_rows[:3])}

相对基线的配对变化：

| 条件 | ΔSPL [95% CI] | ΔDS [95% CI] | Δ步数 [95% CI] |
|---|---:|---:|---:|
| 8×8 | {diff_text('obs8','SPL')} | {diff_text('obs8','DS')} | {diff_text('obs8','steps')} |
| 10×10 | {diff_text('obs10','SPL')} | {diff_text('obs10','DS')} | {diff_text('obs10','steps')} |

8×8 的主要收益出现在 ep07：实际前进步数由 37 降到 17，覆盖率达到 96.3%。但各局变化不一致，SPL 区间跨 0。10×10 的 SPL 与 8×8 持平，DS 和 AP 反而下降。

![观测范围对比](figs/fig1_observation.png)

## 二、每一步评分反馈

反馈组在下一步提示词中加入上一步的 `DS/P/V/M/C/G`，其余输入与基线相同。

| 条件 | SR | SPL | DS | STK | GRD | 步/局 |
|---|---:|---:|---:|---:|---:|---:|
| 5×5 基线 | {fmt_pct(m['base']['SR'])} | {fmt(m['base']['SPL'])} | {fmt(m['base']['DS'])} | {fmt(m['base']['STK'])} | {m['base']['GRD']} | {m['base']['steps']:.1f} |
| 评分反馈 | {fmt_pct(m['feedback']['SR'])} | {fmt(m['feedback']['SPL'])} | {fmt(m['feedback']['DS'])} | {fmt(m['feedback']['STK'])} | {m['feedback']['GRD']} | {m['feedback']['steps']:.1f} |

SPL 配对差为 {diff_text('feedback','SPL')}。低分后的行为也出现变化：

| 条件 | 下一步前进 | 下一步 P=1 | 踏入新格比例 |
|---|---:|---:|---:|
| 5×5 基线 | {feedback_behavior['base']['after_low_next_P_mean']:.3f} | {feedback_behavior['base']['after_low_next_P_eq_1']*100:.1f}% | {feedback_behavior['base']['after_low_new_cell_rate']*100:.1f}% |
| 评分反馈 | {feedback_behavior['feedback']['after_low_next_P_mean']:.3f} | {feedback_behavior['feedback']['after_low_next_P_eq_1']*100:.1f}% | {feedback_behavior['feedback']['after_low_new_cell_rate']*100:.1f}% |

模型能够读取分数并改变动作，但当前数值反馈没有转化为更好的路径效率。ep03 中，基线为 22 个动作、SPL 0.818；反馈组为 60 个动作、SPL 0.273。

![评分反馈对比](figs/fig2_feedback.png)

## 三、地图分辨率

分辨率实验采用 `30×30 + 10×10`，使细网格下的局部观测仍覆盖与基线相同的物理范围；起点、终点和房间连通关系保持不变。

| 条件 | SR | SPL | ER | 物理 NE |
|---|---:|---:|---:|---:|
| 5×5 基线 | {fmt_pct(m['base']['SR'])} | {fmt(m['base']['SPL'])} | {fmt(m['base']['ER'])} | 0.000 |
| 30×30 + 10×10 | {fmt_pct(m['res']['SR'])} | {fmt(m['res']['SPL'])} | {fmt(m['res']['ER'])} | {m['res']['NE']/2:.3f} |

相对基线的配对差：

| ΔSPL [95% CI] | ΔER [95% CI] | Δ物理 NE [95% CI] |
|---:|---:|---:|
| {diff_text('res','SPL')} | {diff_text('res','ER')} | {ne_res_phys[0]:+.3f} [{ne_res_phys[1]:+.3f}, {ne_res_phys[2]:+.3f}] |

原始模型动作数为 19.2 对 38.6，这是细网格下一次动作只移动半个物理格的直接结果，因此只作为调用成本报告，不进入导航质量比较。SPL 和 ER 均按各尺度自身的最短物理路径归一化，SR 与动作粒度无关，物理 NE 已由细格换算回 15×15 格单位。

在该细粒度动作设置下，提高分辨率没有改善 SR、SPL、ER 或物理 NE，并出现 1 次 100 步未到达。该结果不能外推为所有高分辨率地图设计均无效；若要求更严格的等物理动作对照，应将“一次动作移动 2 个细格”实现为宏动作后重新测试。

**关于路径步数是否应进入指标：** SR 不应与步数挂钩；SPL 和 ER 应保留路径距离，但必须使用物理长度并除以该尺度下的最短路径，否则无法区分“到达终点但严重绕路”和“最短路径到达”。不应进入公平性能分数的是原始细格动作数、LLM 调用数和跨尺度直接比较的 DS。当前分辨率结论只采用 SR、SPL、ER 与物理 NE。

**为什么更高分辨率可能没有收益。** 本轮 30×30 是 15×15 的精确 2× 复制放大：每个原格变成 2×2 个相同小格，没有新增门洞、家具、窄道或不规则障碍。因此环境的信息量没有增加，只是坐标数值、节点数量和走完整张图的动作次数增加。对这种以矩形房间和 L 型走廊为主、结构较简单的场景，高分辨率主要带来冗余表示和更长的上下文，理论上不会自动提高导航效果。

**更高分辨率何时可能有效。** 如果场景包含不规则杂物、家具、窄通道、局部凸起或需要精确安全距离的障碍，更细网格能够表达粗网格会抹掉的空间结构；此时高分辨率可能改善碰撞规避、局部通行判断和建图精度。当前结果不能否定这种情况：它只说明“无新增细节的纯放大”没有收益。要验证这一收益，需要构造配对地图：相同的物理起点、终点和房间轮廓，在 15×15 中只保留粗障碍，在 30×30 中加入细粒度不规则障碍；同时保持相同物理视野，并把一次动作设为移动两个细格，避免动作粒度再次成为混杂因素。

![分辨率对比](figs/fig3_resolution.png)

## 四、AP 分项分析

原 AP 为 `(格子准确率 + 边 Jaccard) / 2`。边 Jaccard 会同时惩罚漏报和误报，而模型每步只输出约 9 条边；观测图扩大后，漏报会机械性拉低 AP。因此进一步拆成三个分项：

- **格子精度**：模型写出的格子标签中正确的比例；
- **边精度**：模型写出的边中正确的比例；
- **边覆盖率**：系统已观测边中被模型写出的比例。

| 条件 | 格子精度 | 边精度 | 边覆盖率 | 原 AP | 报告边数 | 观测边数 |
|---|---:|---:|---:|---:|---:|---:|
{chr(10).join(ap_rows)}

逐条件分析：

- **5×5 基线**：格子精度 0.878、边精度 0.917，原 AP 0.521。误差主要不是写错，而是边覆盖率只有 0.163。
- **8×8**：格子精度升到 0.886、边精度仍有 0.906，但观测边从平均 69.1 增至 95.3，边覆盖率降到 0.108，因此 AP 下降。这里不是地图判断整体变差。
- **10×10**：格子精度降至 0.830、边精度降至 0.852、覆盖率 0.086。可见视野更大时，模型反而更难把更多信息压缩成准确的局部地图。
- **评分反馈**：格子精度 0.860、边精度 0.895、覆盖率 0.151，三项均低于基线；更多历史与数值反馈增加了地图输出的注意力负担，并伴随更长轨迹。
- **30×30 + 10×10**：格子精度 0.861、边精度 0.879，与基线差距不大；但观测边增至 302.7 条，而模型只报告 8.9 条，覆盖率仅 0.041，导致原 AP 明显下降。

![AP 分项](figs/fig6_ap_analysis.png)

**结论：** 原 AP 混合了“预测是否正确”和“是否覆盖足够多的已观测边”，不适合直接跨分辨率比较。后续应以格子精度、边精度衡量地图质量，以边覆盖率单独衡量完整性。分辨率实验的主结论不依赖 AP。

## 五、实际路径

十幅地图使用相同的起点、终点与最短路径。橙色轨迹已换算回 15×15 物理坐标。

![十幅地图的实际轨迹](figs/fig4_maps.png)

逐局路径评分：

| 条件 | ep00 | ep01 | ep02 | ep03 | ep04 | ep05 | ep06 | ep07 | ep08 | ep09 | 均值 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(path_rows)}

完整路线与长度见 [per_episode_path_scores.csv](data/per_episode_path_scores.csv)。

## 六、逐步得分

左图为各步 DS 的局间平均，右图为 P/V/M/C/G 的总平均分。逐步明细见 [step_scores.csv](data/step_scores.csv)。

DS 包含建图项 `M` 和新颖项 `V`，会随网格粒度变化，因此仅用于观察决策过程和稳定性，不作为跨分辨率性能结论。

| 条件 | P | V | M | C | G |
|---|---:|---:|---:|---:|---:|
{chr(10).join(component_rows)}

![DS 与五项分项](figs/fig5_step_scores.png)

## 结论

1. 8×8 在当前数据上取得最高 SPL，但 10 张地图的配对区间跨 0，需扩大样本验证。
2. 直接提供完整分数会改变模型行为，但当前实现降低了路径效率。
3. 在当前细粒度动作实现下，同物理视野提高分辨率未改善 SR、SPL、ER 或物理 NE。该实验只放大网格，没有增加不规则障碍；因此不能否定高分辨率对复杂杂物场景的价值，后续需要配对复杂地图和等物理宏动作实验。
4. AP 下降主要受边覆盖率影响。跨分辨率评价应改用格子精度、边精度的组合，并单独报告覆盖率。

## 数据

- [条件指标](data/condition_metrics.csv)
- [逐局路径评分](data/per_episode_path_scores.csv)
- [逐步得分](data/step_scores.csv)
- [AP 分解明细](data/ap_components.csv)
- [AP 分项汇总](data/ap_analysis.json)
- [统计结果](data/analysis.json)
- [原始日志、提示词、模型输出与代码](data/raw_results_and_code.tar.gz)

共 50 局、1137 次模型调用，均完成有效记录。
"""
    (STAGE / "10.26汇报" / "README.md").write_text(report, encoding="utf-8")
    (OUT / "MapGPT_三任务实验报告.md").write_text(report, encoding="utf-8")
    for p in FIGS.iterdir():
        shutil.copy2(p, OUT / p.name)
    for p in DATA.iterdir():
        shutil.copy2(p, OUT / p.name)
    print(json.dumps({GROUPS[g][1]: {k: round(v, 4) for k, v in m[g].items() if k != "_ep"} for g in GROUPS},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
