# -*- coding: utf-8 -*-
"""Build the concise five-condition report, figures, data, and raw bundle."""
import base64
import csv
import json
import random
import shutil
import tarfile
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "vm_results"
OUT = ROOT.parent.parent / "outputs"
STAGE = ROOT.parent / "github_stage_5"
DATA = STAGE / "10.26汇报" / "data"
FIGS = STAGE / "10.26汇报" / "figs"

GROUPS = {
    "base": (["v4_obs5_base_a", "v4_obs5_base_b"], "5×5 基线"),
    "obs8": (["v4_obs8_a", "v4_obs8_b"], "8×8 观测"),
    "obs10": (["v4_obs10_a", "v4_obs10_b"], "10×10 观测"),
    "feedback": (["v4_scorefb_a", "v4_scorefb_b"], "评分反馈"),
    "res": (["v4_res2_obs10_a", "v4_res2_obs10_b"], "30×30 + 10×10"),
}
COLORS = {
    "base": "#1f2937",
    "obs8": "#0f766e",
    "obs10": "#2563eb",
    "feedback": "#7c3aed",
    "res": "#ea580c",
}


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def fnum(v, default=0.0):
    try:
        return float(v)
    except (ValueError, TypeError):
        return default


def load():
    episodes, steps = {}, {}
    for key, (tags, _) in GROUPS.items():
        episodes[key] = []
        steps[key] = []
        for tag in tags:
            episodes[key].extend(read_csv(RAW / f"results_{tag}" / "episodes.csv"))
            steps[key].extend(read_csv(RAW / f"results_{tag}" / "steps.csv"))
        episodes[key].sort(key=lambda r: int(fnum(r["episode"])))
        steps[key].sort(key=lambda r: (int(fnum(r["episode"])), int(fnum(r["step"]))))
    return episodes, steps


def metrics(rows, step_rows):
    n = len(rows)
    total_steps = sum(int(fnum(r["steps"])) for r in rows)
    scale = fnum(rows[0]["res_scale"], 1) if rows else 1
    return {
        "N": n,
        "SR": mean(str(r["success"]).lower() == "true" for r in rows),
        "SPL": mean(
            (1.0 if str(r["success"]).lower() == "true" else 0.0)
            * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1)
            for r in rows
        ),
        "NE": mean(fnum(r["ne"]) for r in rows),
        "NE_physical": mean(fnum(r["ne"]) for r in rows) / scale,
        "ER": mean(
            fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1)
            for r in rows
        ),
        "AP": mean(fnum(r["ap"]) for r in rows),
        "DS": mean(fnum(r["ds_mean"]) for r in rows),
        "COV": mean(fnum(r["coverage"]) for r in rows),
        "STK": sum(int(fnum(r["stuck_steps"])) for r in rows) / total_steps,
        "GRD": sum(int(fnum(r["guard_count"])) for r in rows),
        "STOPREJ": sum(int(fnum(r["stop_rejected"])) for r in rows),
        "steps": total_steps / n,
        "calls": sum(int(fnum(r["llm_calls"])) for r in rows),
        "calls_ep": sum(int(fnum(r["llm_calls"])) for r in rows) / n,
        "P": mean(fnum(r["P"]) for r in step_rows),
        "V": mean(fnum(r["V"]) for r in step_rows),
        "M": mean(fnum(r["M"]) for r in step_rows),
        "C": mean(fnum(r["C"]) for r in step_rows),
        "G": mean(fnum(r["G"]) for r in step_rows),
    }


def per_ep(rows):
    out = {}
    for r in rows:
        s = 1.0 if str(r["success"]).lower() == "true" else 0.0
        out[int(fnum(r["episode"]))] = {
            "SR": s,
            "SPL": s * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1),
            "ER": fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1),
            "NE": fnum(r["ne"]),
            "AP": fnum(r["ap"]),
            "DS": fnum(r["ds_mean"]),
            "steps": fnum(r["steps"]),
        }
    return out


def paired_diff(base, other, metric):
    common = sorted(set(base) & set(other))
    d = [other[i][metric] - base[i][metric] for i in common]
    rng = random.Random(20261027)
    boots = sorted(mean(d[rng.randrange(len(d))] for _ in d) for _ in range(16000))
    return mean(d), boots[int(0.025 * len(boots))], boots[int(0.975 * len(boots)) - 1]


def route_cells(step_rows, scale=1):
    pts = []
    for r in step_rows:
        p = r.get("pose_after", "").split(",")
        if len(p) < 2:
            continue
        xy = (float(p[0]) / scale, float(p[1]) / scale)
        if not pts or pts[-1] != xy:
            pts.append(xy)
    return pts


def fmt_pct(x):
    return f"{x * 100:.1f}%"


def fmt(x):
    return f"{x:.3f}"


def savefig(name):
    p = FIGS / name
    plt.savefig(p, dpi=190, bbox_inches="tight")
    plt.close()
    return p


def draw_observation(m):
    groups = ["base", "obs8", "obs10"]
    labels = [GROUPS[g][1] for g in groups]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    x = np.arange(3)
    width = 0.24
    for i, key in enumerate(("SR", "SPL", "DS")):
        axes[0].bar(
            x + (i - 1) * width,
            [m[g][key] for g in groups],
            width,
            label=key,
            color=["#64748b", "#0891b2", "#7c3aed"][i],
        )
    axes[0].set_xticks(x, labels)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Navigation metrics")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    axes[1].bar(x, [m[g]["steps"] for g in groups], color=[COLORS[g] for g in groups])
    axes[1].set_xticks(x, labels)
    axes[1].set_title("Average actions per episode")
    axes[1].set_ylabel("actions")
    axes[1].grid(axis="y", alpha=0.2)

    for g in groups:
        vals = [m[g].get("_ep", {}).get(i, float("nan")) for i in range(10)]
        axes[2].plot(range(10), vals, "o-", label=GROUPS[g][1], color=COLORS[g])
    axes[2].set_xticks(range(10), [f"{i:02d}" for i in range(10)])
    axes[2].set_ylim(0, 1.05)
    axes[2].set_title("Per-episode SPL")
    axes[2].legend(frameon=False, fontsize=8)
    axes[2].grid(alpha=0.2)
    fig.tight_layout()
    savefig("fig1_observation.png")


def draw_feedback(m, stats):
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    groups = ["base", "feedback"]
    labels = [GROUPS[g][1] for g in groups]
    x = np.arange(2)
    width = 0.24
    names = ["SR", "SPL", "DS"]
    for i, (name, color) in enumerate(zip(names, ("#64748b", "#0891b2", "#7c3aed"))):
        axes[0].bar(x + (i - 1) * width, [m[g][name] for g in groups], width,
                    label=name, color=color)
    axes[0].set_xticks(x, labels)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Baseline vs score feedback")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    keys = ["after_low_next_P_mean", "after_low_next_P_eq_1", "after_low_new_cell_rate"]
    names = ["Next P", "Next P=1", "New cell"]
    x = np.arange(3)
    axes[1].bar(x - 0.18, [stats["base"][k] for k in keys], 0.36, label="无反馈", color="#64748b")
    axes[1].bar(x + 0.18, [stats["feedback"][k] for k in keys], 0.36, label="有反馈", color="#7c3aed")
    axes[1].set_xticks(x, names)
    axes[1].set_ylim(0, 1.05)
    axes[1].set_title("Behavior after a low-scoring step")
    axes[1].legend(frameon=False)
    axes[1].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig2_feedback.png")


def draw_resolution(m):
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    groups = ["base", "res"]
    labels = ["5×5 基线", "30×30 + 10×10"]
    x = np.arange(3)
    width = 0.34
    metrics_names = ["SR", "SPL", "ER"]
    for i, g in enumerate(groups):
        axes[0].bar(x + (i - 0.5) * width, [m[g][k] for k in metrics_names], width,
                    label=labels[i], color=COLORS[g])
    axes[0].set_xticks(x, metrics_names)
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("Scale-normalized navigation metrics")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    ne_physical = [m["base"]["NE"], m["res"]["NE"] / 2.0]
    axes[1].bar([0, 1], ne_physical, color=[COLORS["base"], COLORS["res"]])
    axes[1].set_xticks([0, 1], labels)
    axes[1].set_title("Physical navigation error")
    axes[1].set_ylabel("15×15-cell units")
    axes[1].grid(axis="y", alpha=0.2)

    axes[2].bar([0, 1], [m["base"]["steps"], m["res"]["steps"]], color=[COLORS["base"], COLORS["res"]])
    axes[2].set_xticks([0, 1], labels)
    axes[2].set_title("Operational cost (not a performance score)")
    axes[2].set_ylabel("model actions")
    axes[2].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig3_resolution.png")


def draw_maps(env_builder, ep_rows, step_rows):
    fig, axes = plt.subplots(5, 2, figsize=(9.5, 19))
    axes = axes.ravel()
    for ep in range(10):
        env = env_builder(ep)
        ax = axes[ep]
        ax.imshow(np.array(env.grid), cmap="Greys", origin="upper", alpha=0.35, vmin=0, vmax=2)
        for g in GROUPS:
            scale = 2 if g == "res" else 1
            rr = [r for r in step_rows[g] if int(fnum(r["episode"])) == ep]
            pts = route_cells(rr, scale)
            if pts:
                ax.plot([p[0] + 0.5 for p in pts], [p[1] + 0.5 for p in pts],
                        color=COLORS[g], lw=1.4, alpha=0.82)
        ax.scatter([env.start[0] + 0.5], [env.start[1] + 0.5], marker="o", s=36,
                   facecolor="#22c55e", edgecolor="black", zorder=5)
        ax.scatter([env.goal[0] + 0.5], [env.goal[1] + 0.5], marker="*", s=95,
                   facecolor="#facc15", edgecolor="black", zorder=5)
        er = next(r for r in ep_rows["base"] if int(fnum(r["episode"])) == ep)
        ax.set_title(f"ep{ep:02d}  l={er['shortest']}  start={er['start']}  goal={er['goal']}", fontsize=9)
        ax.set_xlim(0, 15)
        ax.set_ylim(15, 0)
        ax.set_xticks([])
        ax.set_yticks([])
    handles = [
        Line2D([0], [0], color=COLORS[g], lw=2, label=GROUPS[g][1])
        for g in GROUPS
    ]
    handles += [
        Line2D([0], [0], marker="o", color="none", markerfacecolor="#22c55e", markeredgecolor="black",
               markersize=8, label="起点"),
        Line2D([0], [0], marker="*", color="none", markerfacecolor="#facc15", markeredgecolor="black",
               markersize=11, label="终点"),
    ]
    fig.legend(handles=handles, loc="upper center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.995))
    fig.tight_layout(rect=(0, 0, 1, 0.975))
    savefig("fig4_maps.png")


def draw_step_scores(step_rows):
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5))
    for g in GROUPS:
        by_step = defaultdict(list)
        for r in step_rows[g]:
            by_step[int(fnum(r["step"]))].append(fnum(r["DS"]))
        xs = sorted(by_step)
        ys = [mean(by_step[x]) for x in xs]
        axes[0].plot(xs, ys, lw=1.8, label=GROUPS[g][1], color=COLORS[g])
    axes[0].set_xlim(0, 60)
    axes[0].set_ylim(0.25, 1.0)
    axes[0].set_xlabel("Within-episode step index")
    axes[0].set_ylabel("Mean DS")
    axes[0].set_title("Step-level composite score")
    axes[0].grid(alpha=0.2)
    axes[0].legend(frameon=False, fontsize=8)

    keys = ["P", "V", "M", "C", "G"]
    x = np.arange(len(keys))
    width = 0.15
    for i, g in enumerate(GROUPS):
        m = {k: mean(fnum(r[k]) for r in step_rows[g]) for k in keys}
        axes[1].bar(x + (i - 2) * width, [m[k] for k in keys], width,
                    label=GROUPS[g][1], color=COLORS[g])
    axes[1].set_xticks(x, keys)
    axes[1].set_ylim(0, 1.05)
    axes[1].set_title("Mean step-score components")
    axes[1].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    savefig("fig5_step_scores.png")


def draw_progress(episodes, step_rows):
    fig, ax = plt.subplots(figsize=(8, 4.5))
    grid = np.linspace(0, 1, 21)
    for g in GROUPS:
        curves = []
        for ep in episodes[g]:
            ep_i = int(fnum(ep["episode"]))
            scale = int(fnum(ep["res_scale"], 1))
            rows = [r for r in step_rows[g] if int(fnum(r["episode"])) == ep_i]
            if not rows:
                continue
            d0 = fnum(rows[0]["d_before"]) / scale
            dists = [fnum(r["d_after"]) / scale for r in rows]
            if d0 <= 0:
                continue
            fractions = np.arange(1, len(dists) + 1) / len(dists)
            curve = np.interp(grid, fractions, dists, left=d0, right=dists[-1])
            curves.append(np.array(curve) / d0)
        arr = np.array(curves)
        ax.plot(grid, arr.mean(axis=0), lw=2.2, color=COLORS[g], label=GROUPS[g][1])
        ax.fill_between(grid, np.percentile(arr, 25, axis=0), np.percentile(arr, 75, axis=0),
                        color=COLORS[g], alpha=0.10)
    ax.set_xlabel("Normalized episode progress")
    ax.set_ylabel("Remaining distance / initial distance")
    ax.set_ylim(0, 1.05)
    ax.set_title("Distance-to-goal during navigation")
    ax.grid(alpha=0.2)
    ax.legend(frameon=False, fontsize=8, ncol=2)
    fig.tight_layout()
    savefig("fig6_progress.png")


def low_score_stats(step_rows):
    out = {}
    for g in ("base", "feedback"):
        by_ep = defaultdict(list)
        for r in step_rows[g]:
            by_ep[int(fnum(r["episode"]))].append(r)
        tr = []
        for rows in by_ep.values():
            rows.sort(key=lambda r: int(fnum(r["step"])))
            tr += [(fnum(a["DS"]), fnum(b["DS"]), fnum(b["P"]), fnum(b["V"]))
                   for a, b in zip(rows, rows[1:])]
        low = [x for x in tr if x[0] <= 0.75]
        out[g] = {
            "after_low_N": len(low),
            "after_low_next_P_mean": mean(x[2] for x in low),
            "after_low_next_P_eq_1": mean(1.0 if x[2] >= 0.999 else 0.0 for x in low),
            "after_low_new_cell_rate": mean(1.0 if x[3] >= 0.999 else 0.0 for x in low),
            "after_low_next_DS_delta": mean(x[1] - x[0] for x in low),
        }
    return out


def main():
    OUT.mkdir(exist_ok=True)
    for d in (DATA, FIGS):
        if d.exists():
            shutil.rmtree(d)
        d.mkdir(parents=True)
    episodes, steps = load()
    m = {g: metrics(episodes[g], steps[g]) for g in GROUPS}
    for g in GROUPS:
        m[g]["_ep"] = {i: per_ep(episodes[g])[i]["SPL"] for i in range(10)}
    effects = {
        g: {
            k: paired_diff(per_ep(episodes["base"]), per_ep(episodes[g]), k)
            for k in ("SR", "SPL", "NE", "AP", "DS", "ER", "steps")
        }
        for g in ("obs8", "obs10", "feedback", "res")
    }
    feedback_behavior = low_score_stats(steps)

    # Filtered data deliverables
    ep_fields = [
        "condition", "episode", "seed", "grid", "observation", "start", "goal",
        "success", "shortest_distance", "actual_distance", "model_actions",
        "path_score_spl", "path_efficiency_er", "final_ne", "route",
    ]
    ep_out = []
    for g in GROUPS:
        for r in episodes[g]:
            ep_i = int(fnum(r["episode"]))
            sr = 1.0 if str(r["success"]).lower() == "true" else 0.0
            pts = route_cells([x for x in steps[g] if int(fnum(x["episode"])) == ep_i],
                              2 if g == "res" else 1)
            ep_out.append({
                "condition": GROUPS[g][1],
                "episode": ep_i,
                "seed": r["seed"],
                "grid": r["grid"],
                "observation": f"{r['obs_size']}×{r['obs_size']}",
                "start": r["start"],
                "goal": r["goal"],
                "success": r["success"],
                "shortest_distance": round(fnum(r["shortest"]) / int(fnum(r["res_scale"], 1)), 6),
                "actual_distance": round(fnum(r["actual"]) / int(fnum(r["res_scale"], 1)), 6),
                "model_actions": r["steps"],
                "path_score_spl": round(sr * fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1), 6),
                "path_efficiency_er": round(fnum(r["shortest"]) / max(fnum(r["actual"]), fnum(r["shortest"]), 1), 6),
                "final_ne": round(fnum(r["ne"]) / int(fnum(r["res_scale"], 1)), 6),
                "route": " -> ".join(f"{x:g},{y:g}" for x, y in pts),
            })
    with open(DATA / "per_episode_path_scores.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=ep_fields)
        w.writeheader()
        w.writerows(ep_out)

    metric_fields = ["N", "SR", "SPL", "NE", "NE_physical", "ER", "AP", "DS", "COV", "STK", "GRD",
                     "STOPREJ", "steps", "calls", "calls_ep", "P", "V", "M", "C", "G"]
    with open(DATA / "condition_metrics.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=["condition"] + metric_fields)
        w.writeheader()
        for g in GROUPS:
            w.writerow({"condition": GROUPS[g][1], **{k: m[g][k] for k in metric_fields}})

    step_fields = [
        "condition", "episode", "step", "pose_after", "action", "moved", "bumped",
        "distance_before", "distance_after", "cumulative_forward_distance",
        "visit_count", "frontier_left", "P_progress", "V_novelty",
        "M_map_quality", "C_cleanliness", "G_goal_commitment", "DS", "source",
    ]
    with open(DATA / "step_scores.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=step_fields)
        w.writeheader()
        for g in GROUPS:
            for ep in range(10):
                cumulative = 0.0
                ep_rows = [r for r in steps[g] if int(fnum(r["episode"])) == ep]
                for r in ep_rows:
                    scale = int(fnum(r["res_scale"], 1))
                    cumulative += int(fnum(r["moved"])) / scale
                    w.writerow({
                        "condition": GROUPS[g][1],
                        "episode": ep,
                        "step": r["step"],
                        "pose_after": r["pose_after"],
                        "action": r["action"],
                        "moved": r["moved"],
                        "bumped": r["bumped"],
                        "distance_before": round(fnum(r["d_before"]) / scale, 6),
                        "distance_after": round(fnum(r["d_after"]) / scale, 6),
                        "cumulative_forward_distance": round(cumulative, 6),
                        "visit_count": r["visit_count"],
                        "frontier_left": r["frontier_left"],
                        "P_progress": r["P"],
                        "V_novelty": r["V"],
                        "M_map_quality": r["M"],
                        "C_cleanliness": r["C"],
                        "G_goal_commitment": r["G"],
                        "DS": r["DS"],
                        "source": r["source"],
                    })

    analysis = {
        "conditions": {g: GROUPS[g][1] for g in GROUPS},
        "metrics": {GROUPS[g][1]: {k: v for k, v in m[g].items() if k != "_ep"} for g in GROUPS},
        "paired_effects_vs_baseline": {GROUPS[g][1]: effects[g] for g in effects},
        "feedback_behavior": {GROUPS[g][1]: feedback_behavior[g] for g in feedback_behavior},
    }
    (DATA / "analysis.json").write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")

    # Figures
    draw_observation(m)
    draw_feedback(m, feedback_behavior)
    draw_resolution(m)

    from mapgpt_vm_demo_v4 import EPISODE_SEED_BASE
    from mapgpt_v4 import build_navigation_env
    draw_maps(lambda ep: build_navigation_env(15, 15, EPISODE_SEED_BASE + ep * 17, 1),
              episodes, steps)
    draw_step_scores(steps)
    draw_progress(episodes, steps)

    # Raw bundle: selected five result directories only, plus code.
    bundle_path = DATA / "raw_results_and_code.tar.gz"
    with tarfile.open(bundle_path, "w:gz") as tf:
        for key, (tags, _) in GROUPS.items():
            for tag in tags:
                tf.add(RAW / f"results_{tag}", arcname=f"results_{tag}")
        for name in ("mapgpt_v4.py", "mapgpt_vm_demo_v4.py", "run_matrix.py",
                     "relay_v4.py", "analyze_ap.py", "make_final5.py"):
            tf.add(ROOT / name, arcname=name)
        tf.add(RAW / "relay_v4.jsonl", arcname="relay_v4.jsonl")

    condition_rows = []
    for g in GROUPS:
        x = m[g]
        condition_rows.append(
            f"| {GROUPS[g][1]} | {fmt_pct(x['SR'])} | {fmt(x['SPL'])} | {fmt(x['NE'])} | "
            f"{fmt(x['AP'])} | {fmt(x['DS'])} | {fmt(x['STK'])} | {x['GRD']} | {x['steps']:.1f} |"
        )
    component_rows = []
    for g in GROUPS:
        x = m[g]
        component_rows.append(
            f"| {GROUPS[g][1]} | {fmt(x['P'])} | {fmt(x['V'])} | {fmt(x['M'])} | {fmt(x['C'])} | {fmt(x['G'])} |"
        )
    path_rows = []
    for g in GROUPS:
        vals = {i: per_ep(episodes[g])[i]["SPL"] for i in range(10)}
        path_rows.append(
            f"| {GROUPS[g][1]} | " + " | ".join(f"{vals[i]:.3f}" for i in range(10))
            + f" | {mean(vals.values()):.3f} |"
        )
    report = f"""# MapGPT 文本网格导航三任务对比实验

实验基于 v3 的锚点、前沿路径、防卡死与 STOP 坐标门，使用 10 个固定种子和 qwen-plus。

## 结果摘要

| 任务 | 主要结果 | 结论 |
|---|---|---|
| 观测范围 | SPL：5×5 0.894，8×8 0.910，10×10 0.909 | 8×8 略优，10×10 无继续增益 |
| 评分反馈 | SPL：0.894 → 0.805；步/局：19.2 → 22.1 | 会改变行为，但未提升效率 |
| 地图分辨率 | SR：100% → 90%；SPL：0.894 → 0.780 | 当前设置下无性能提升 |

## 实验设置

- 15×15 地图 10 幅，种子 `20240928 + 17i`。
- 动作空间：`FORWARD / LEFT / RIGHT / STOP`。
- 局部观测以机器人为中心，墙体阻断视线。
- qwen-plus，`temperature=0`，`max_tokens=700`。
- 30×30 由同一地图精确 2× 放大；10×10 观测保持原物理视野。

## 一、观测范围

| 条件 | SR | SPL | NE | AP | DS | 步/局 |
|---|---:|---:|---:|---:|---:|---:|
| 5×5 基线 | {fmt_pct(m['base']['SR'])} | {fmt(m['base']['SPL'])} | {fmt(m['base']['NE'])} | {fmt(m['base']['AP'])} | {fmt(m['base']['DS'])} | {m['base']['steps']:.1f} |
| 8×8 观测 | {fmt_pct(m['obs8']['SR'])} | {fmt(m['obs8']['SPL'])} | {fmt(m['obs8']['NE'])} | {fmt(m['obs8']['AP'])} | {fmt(m['obs8']['DS'])} | {m['obs8']['steps']:.1f} |
| 10×10 观测 | {fmt_pct(m['obs10']['SR'])} | {fmt(m['obs10']['SPL'])} | {fmt(m['obs10']['NE'])} | {fmt(m['obs10']['AP'])} | {fmt(m['obs10']['DS'])} | {m['obs10']['steps']:.1f} |

![观测范围对比](figs/fig1_observation.png)

### 结果分析

- **5×5 基线：** SR 为 100%，SPL 0.894；局部信息较少，但路径效率已较高。
- **8×8：** SPL 升到 0.910，平均步数从 19.2 降到 16.1，覆盖率提高到 96.3%，是本轮点估计最好的设置。
- **10×10：** SPL 0.909，与 8×8 基本持平；AP、DS 未继续提高，guard 增至 4 次，说明增加视窗没有带来稳定收益。

10 幅地图的配对区间跨 0，因此 8×8 只作为优先候选，尚不能宣称显著优于基线。

## 二、评分反馈

反馈组在下一步提示词中加入上一步的 `DS/P/V/M/C/G`，其余输入与基线相同。

| 条件 | SR | SPL | DS | 步/局 | guard |
|---|---:|---:|---:|---:|---:|
| 5×5 基线 | {fmt_pct(m['base']['SR'])} | {fmt(m['base']['SPL'])} | {fmt(m['base']['DS'])} | {m['base']['steps']:.1f} | {m['base']['GRD']} |
| 评分反馈 | {fmt_pct(m['feedback']['SR'])} | {fmt(m['feedback']['SPL'])} | {fmt(m['feedback']['DS'])} | {m['feedback']['steps']:.1f} | {m['feedback']['GRD']} |

![评分反馈对比](figs/fig2_feedback.png)

### 结果分析

- 两组 SR 均为 100%，说明反馈没有破坏最终到达能力。
- SPL 从 0.894 降到 0.805，平均动作数从 19.2 增到 22.1，guard 从 3 次增到 8 次，路径效率明显下降。
- 低分之后，模型进入新格的比例从 69.4% 降到 55.8%，更倾向于反复转向或检查。原因是完整数值反馈没有告诉模型应该采取什么动作，反而增加了主观负担。

因此，评分反馈确实影响下一步决策，但当前直接展示数值的方式不适合作为性能优化手段。

## 三、地图分辨率

| 条件 | SR | SPL | ER | 物理 NE | 模型动作/局 |
|---|---:|---:|---:|---:|---:|
| 5×5 基线 | {fmt_pct(m['base']['SR'])} | {fmt(m['base']['SPL'])} | {fmt(m['base']['ER'])} | 0.000 | {m['base']['steps']:.1f} |
| 30×30 + 10×10 | {fmt_pct(m['res']['SR'])} | {fmt(m['res']['SPL'])} | {fmt(m['res']['ER'])} | {m['res']['NE']/2:.3f} | {m['res']['steps']:.1f} |

![分辨率对比](figs/fig3_resolution.png)

### 结果分析

- **成功率：** 基线 10/10 成功，高分辨率 9/10 成功；后者有一局达到 100 步上限。
- **路径效率：** SPL 0.894→0.780，ER 0.894→0.826，说明高分辨率下绕行更多。
- **计算成本：** 平均模型动作数由 19.2 增到 38.6。该数值不进入性能分数，因为高分辨率下一次动作只移动半个物理格。

**指标公平性：** SR 不受路径长度影响；SPL、ER 保留路径距离，但使用物理距离相对各自最短路径归一化。NE 只表示整局结束后的最终误差，因此成功局均为 0，不用于反映逐步接近终点的过程。原始动作数和 LLM 调用数只作为成本。

**适用边界：** 本轮 30×30 是原地图的无损 2× 放大，没有新增障碍细节，所以结果不否定高分辨率对复杂杂物场景的价值。若要验证该收益，需要加入细粒度不规则障碍，并把一次动作设计为移动两个细格。

![逐步剩余距离](figs/fig6_progress.png)

上图按每局进度归一化后展示“当前位置到终点的距离 / 初始距离”。曲线持续下降，而 NE 只取曲线终点，因此成功局为 0 并不表示途中没有靠近目标。

## 四、指标定义

| 指标 | 公式 | 含义 |
|---|---|---|
| SR | `mean(S_i)` | 是否成功到达终点 |
| SPL | `mean(S_i × l_i / max(d_i,l_i))` | 按最短路径加权的成功率 |
| ER | `mean(l_i / max(d_i,l_i))` | 不区分成败的路径效率 |
| NE | `mean(d(end_i, goal_i))` | 最终位置到终点的距离 |
| AP | `mean((cell_acc + edge_J) / 2)` | 格子精度与边 Jaccard 的均值 |
| DS | `0.30P + 0.20V + 0.25M + 0.15C + 0.10G` | 单步综合诊断分 |

其中 `l_i` 为最短物理路径，`d_i` 为实际前进的物理距离，`M=AP`。

| DS 分项 | 定义 |
|---|---|
| `P` 进度 | 靠近终点为 1，距离不变为 0.5，远离为 0 |
| `V` 新颖性 | 新格为 1，旧格为 0.5，原地转向为 0.25，撞墙为 0 |
| `M` 建图 | 当前步的 AP |
| `C` 洁净度 | 正常为 1，卡死告警为 0.5，guard 接管为 0 |
| `G` 目标承诺 | 子目标稳定或已到达为 1，逻辑失效为 0.75，乱换为 0，缺失为 0.5 |

`step_scores.csv` 中的 `P_progress / V_novelty / M_map_quality / C_cleanliness / G_goal_commitment` 就是这五项的完整名称。

## 五、实际路径

![十幅地图的实际轨迹](figs/fig4_maps.png)

| 条件 | ep00 | ep01 | ep02 | ep03 | ep04 | ep05 | ep06 | ep07 | ep08 | ep09 | 均值 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(path_rows)}

## 六、逐步得分

![DS 与五项分项](figs/fig5_step_scores.png)

图中共有五个评分分项与加权总分 DS。CSV 中另列动作、位置、步前后距离、累计前进距离和访问次数，用于核对轨迹；这些不是新的评分项。

## 结论

1. 8×8 取得最高 SPL，但 10 幅地图不足以确认稳定增益。
2. 直接反馈完整评分会改变模型行为，但没有提升导航效率。
3. 当前分辨率实验只增加地图粒度，没有增加环境细节；高分辨率能否帮助复杂杂物场景仍待专门实验验证。

## 数据

- [条件指标](data/condition_metrics.csv)
- [逐局路径评分](data/per_episode_path_scores.csv)
- [逐步得分](data/step_scores.csv)
- [统计结果](data/analysis.json)
- [原始日志、提示词、模型输出与代码](data/raw_results_and_code.tar.gz)

共 50 局、1137 次模型调用。
"""
    (STAGE / "10.26汇报" / "README.md").write_text(report, encoding="utf-8")
    (OUT / "MapGPT_三任务实验报告.md").write_text(report, encoding="utf-8")
    for p in FIGS.iterdir():
        shutil.copy2(p, OUT / p.name)
    for p in DATA.iterdir():
        shutil.copy2(p, OUT / p.name)
    print(json.dumps({GROUPS[g][1]: {k: round(v, 4) for k, v in m[g].items() if k != "_ep"} for g in GROUPS},
                     ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
