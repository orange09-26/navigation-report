# -*- coding: utf-8 -*-
"""Recompute AP components from raw VM logs and replay each executed step."""
import csv
import json
import re
from collections import defaultdict
from pathlib import Path
from statistics import mean

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import mapgpt_vm_demo_v4 as d
from mapgpt_v4 import build_navigation_env

plt.rcParams["font.sans-serif"] = ["Microsoft YaHei", "SimHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "vm_results"
STAGE = ROOT.parent / "github_stage_5" / "10.26汇报"
DATA = STAGE / "data"
FIGS = STAGE / "figs"
OUT = ROOT.parent.parent / "outputs"
GROUPS = {
    "base": ["v4_obs5_base_a", "v4_obs5_base_b"],
    "obs8": ["v4_obs8_a", "v4_obs8_b"],
    "obs10": ["v4_obs10_a", "v4_obs10_b"],
    "feedback": ["v4_scorefb_a", "v4_scorefb_b"],
    "res": ["v4_res2_obs10_a", "v4_res2_obs10_b"],
}
LABELS = {
    "base": "5×5 基线",
    "obs8": "8×8 观测",
    "obs10": "10×10 观测",
    "feedback": "评分反馈",
    "res": "30×30 + 10×10",
}


def fnum(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def read_csv(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def ap_parts(parsed, env):
    pred_cells = dict(parsed.get("pred_cells") or {})
    pred_cells.update(d.align_ascii_cells(parsed.get("ascii_rows"), parsed.get("ascii_robot"), env))
    judged = [(xy, lab) for xy, lab in pred_cells.items()
              if isinstance(xy[0], int) and env.in_bounds(*xy)]
    ok = sum(1 for xy, lab in judged if env.true_cell_label(*xy) == lab)
    cell_acc = ok / len(judged) if judged else 0.0

    known = set(env.topo_nodes.values())
    pred_edges = {e for e in (parsed.get("pred_edges") or set())
                  if e[0] in known and e[1] in known}
    true_edges = set(env.topo_edges)
    correct_edges = pred_edges & true_edges
    edge_j = len(correct_edges) / max(len(pred_edges | true_edges), 1)
    edge_precision = len(correct_edges) / max(len(pred_edges), 1)
    edge_recall = len(correct_edges) / max(len(true_edges), 1)
    return {
        "cell_acc": cell_acc,
        "cell_n": len(judged),
        "cell_ok": ok,
        "edge_j": edge_j,
        "edge_precision": edge_precision,
        "edge_recall": edge_recall,
        "correct_edge_n": len(correct_edges),
        "pred_edge_n": len(pred_edges),
        "obs_edge_n": len(true_edges),
        "node_n": len(known),
        "ap": (cell_acc + edge_j) / 2,
        "precision_ap": (cell_acc + edge_precision) / 2,
    }


def analyze_group(key, tags):
    rows = []
    for tag in tags:
        base = RAW / f"results_{tag}"
        eps = read_csv(base / "episodes.csv")
        sts = read_csv(base / "steps.csv")
        log = (base / "log.txt").read_text(encoding="utf-8", errors="replace")
        blocks = re.findall(r"LLM_BEGIN\n(.*?)\nLLM_END", log, re.S)
        if len(blocks) != len(sts):
            raise RuntimeError(f"{tag}: blocks={len(blocks)} steps={len(sts)}")
        by_ep = defaultdict(list)
        for r in sts:
            by_ep[int(fnum(r["episode"]))].append(r)
        cursor = 0
        for ep in eps:
            epi = int(fnum(ep["episode"]))
            scale = int(fnum(ep["res_scale"], 1))
            d.OBS_SIZE = int(fnum(ep["obs_size"]))
            env = build_navigation_env(int(ep["grid"].split("x")[0]),
                                       int(ep["grid"].split("x")[1]),
                                       int(ep["seed"]), scale)
            for step in by_ep[epi]:
                block = blocks[cursor]
                cursor += 1
                parsed = d.parse_llm_response(block)
                x = ap_parts(parsed, env)
                rows.append({
                    "group": LABELS[key],
                    "episode": epi,
                    "step": int(fnum(step["step"])),
                    **x,
                })
                env.step(step["action"])
    return rows


def main():
    all_rows = []
    for key, tags in GROUPS.items():
        all_rows.extend(analyze_group(key, tags))

    fields = ["group", "episode", "step", "ap", "precision_ap", "cell_acc", "cell_n", "cell_ok",
              "edge_j", "edge_precision", "edge_recall", "correct_edge_n",
              "pred_edge_n", "obs_edge_n", "node_n"]
    with open(DATA / "ap_components.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(all_rows)

    agg = {}
    for key in GROUPS:
        rows = [r for r in all_rows if r["group"] == LABELS[key]]
        by_ep = defaultdict(list)
        for r in rows:
            by_ep[r["episode"]].append(r)
        agg[LABELS[key]] = {
            "steps": len(rows),
            # AP is defined as the mean of episode means, not a step-weighted mean.
            "AP": mean(mean(r["ap"] for r in rr) for rr in by_ep.values()),
            "precision_AP": mean(mean(r["precision_ap"] for r in rr) for rr in by_ep.values()),
            "cell_acc": mean(mean(r["cell_acc"] for r in rr) for rr in by_ep.values()),
            "edge_J": mean(mean(r["edge_j"] for r in rr) for rr in by_ep.values()),
            "edge_precision": mean(mean(r["edge_precision"] for r in rr) for rr in by_ep.values()),
            "edge_recall": mean(mean(r["edge_recall"] for r in rr) for rr in by_ep.values()),
            "cell_n": mean(r["cell_n"] for r in rows),
            "pred_edges": mean(r["pred_edge_n"] for r in rows),
            "observed_edges": mean(r["obs_edge_n"] for r in rows),
            "known_nodes": mean(r["node_n"] for r in rows),
        }
    (DATA / "ap_analysis.json").write_text(json.dumps(agg, ensure_ascii=False, indent=2), encoding="utf-8")

    fig, axes = plt.subplots(1, 2, figsize=(12.5, 4.5))
    labels = [LABELS[g] for g in GROUPS]
    x = np.arange(len(labels))
    width = 0.24
    axes[0].bar(x - width, [agg[l]["cell_acc"] for l in labels], width,
                label="格子精度", color="#0891b2")
    axes[0].bar(x, [agg[l]["edge_precision"] for l in labels], width,
                label="边精度", color="#7c3aed")
    axes[0].bar(x + width, [agg[l]["edge_recall"] for l in labels], width,
                label="边覆盖率", color="#dc2626")
    axes[0].set_xticks(x, labels, rotation=18, ha="right")
    axes[0].set_ylim(0, 1.05)
    axes[0].set_title("AP components")
    axes[0].legend(frameon=False)
    axes[0].grid(axis="y", alpha=0.2)

    axes[1].bar(x - 0.18, [agg[l]["pred_edges"] for l in labels], 0.36,
                label="模型报告边数", color="#f59e0b")
    axes[1].bar(x + 0.18, [agg[l]["observed_edges"] for l in labels], 0.36,
                label="系统已观测边数", color="#475569")
    axes[1].set_xticks(x, labels, rotation=18, ha="right")
    axes[1].set_title("Connectivity output vs observed graph")
    axes[1].legend(frameon=False)
    axes[1].grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(FIGS / "fig6_ap_analysis.png", dpi=190, bbox_inches="tight")
    plt.close(fig)

    print(json.dumps(agg, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
