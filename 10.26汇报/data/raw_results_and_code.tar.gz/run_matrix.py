# -*- coding: utf-8 -*-
"""Run the v4 experiment matrix with bounded subprocess concurrency."""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path("/home/orange")
SCRIPT = ROOT / "mapgpt_v4.py"
LOGDIR = ROOT / "matrix_v4_logs"
MAX_WORKERS = int(os.getenv("MATRIX_WORKERS", "4"))
SLEEP_OK = os.getenv("MAPGPT_SLEEP_OK", "0.2")
STAMP = time.strftime("%Y%m%d_%H%M%S")


def job(tag, obs, feedback="none", grid=(15, 15), scale=1):
    jobs = []
    for part, start in (("a", 0), ("b", 5)):
        jobs.append({
            "tag": f"{tag}_{part}",
            "start": start,
            "num": 5,
            "obs": obs,
            "feedback": feedback,
            "grid": grid,
            "scale": scale,
        })
    return jobs


JOBS = []
JOBS += job("v4_obs5_base", 5)
JOBS += job("v4_obs8", 8)
JOBS += job("v4_obs10", 10)
JOBS += job("v4_scorefb", 5, feedback="full")
JOBS += job("v4_res2_obs10", 10, grid=(30, 30), scale=2)
JOBS += job("v4_res2_obs5", 5, grid=(30, 30), scale=2)
# Independent repeat, launched after a different portion of the matrix.
JOBS += job("v4_obs5_repeat", 5)


def done(j):
    return (ROOT / f"results_{j['tag']}" / "summary.txt").exists()


def launch(j):
    outdir = LOGDIR / f"{j['tag']}.out"
    errdir = LOGDIR / f"{j['tag']}.err"
    out = open(outdir, "w", encoding="utf-8")
    err = open(errdir, "w", encoding="utf-8")
    env = dict(os.environ)
    env["MAPGPT_LLM_URL"] = "http://127.0.0.1:5000/get_llm_response"
    env["MAPGPT_SLEEP_OK"] = SLEEP_OK
    env["MAPGPT_MODEL"] = "qwen-plus"
    nonce = f"{j['tag']}_{STAMP}"
    cmd = [
        sys.executable, str(SCRIPT),
        "--start-ep", str(j["start"]),
        "--num-ep", str(j["num"]),
        "--grid", str(j["grid"][0]), str(j["grid"][1]),
        "--obs-size", str(j["obs"]),
        "--score-feedback", j["feedback"],
        "--res-scale", str(j["scale"]),
        "--max-steps", "100",
        "--tag", j["tag"],
        "--nonce", nonce,
    ]
    proc = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=out, stderr=err)
    return proc, out, err, cmd


def main():
    LOGDIR.mkdir(exist_ok=True)
    # Interleave conditions so drift cannot align with a single condition.
    pending = [j for j in JOBS if not done(j)]
    completed = [j["tag"] for j in JOBS if done(j)]
    with open(LOGDIR / f"matrix_{STAMP}.json", "w", encoding="utf-8") as f:
        json.dump({"all": JOBS, "already_done": completed, "workers": MAX_WORKERS}, f, indent=2)
    running = {}
    processed = 0
    while pending or running:
        while pending and len(running) < MAX_WORKERS:
            j = pending.pop(0)
            proc, out, err, cmd = launch(j)
            running[j["tag"]] = (proc, out, err)
            print(f"START {j['tag']} pid={proc.pid} cmd={' '.join(cmd)}", flush=True)
        finished = []
        for tag, (proc, out, err) in running.items():
            rc = proc.poll()
            if rc is None:
                continue
            out.close()
            err.close()
            print(f"END {tag} rc={rc}", flush=True)
            finished.append(tag)
            processed += 1
        for tag in finished:
            running.pop(tag)
        time.sleep(3)
    print(f"MATRIX_DONE stamp={STAMP} processed={processed}", flush=True)


if __name__ == "__main__":
    main()
