import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET


QUERIES = {
    "dpwm": 'ti:"Diffusion-Based Map Prediction Guided Planning"',
    "map_prediction_nav": 'all:"map prediction" AND all:navigation',
    "frontier_nav": 'all:"frontier" AND all:"vision-language navigation"',
    "map_completion_nav": 'all:"map completion" AND all:navigation',
    "deadlock_nav": 'all:"deadlock" AND all:navigation',
}
NS = {"a": "http://www.w3.org/2005/Atom"}

for name, query in QUERIES.items():
    url = "https://export.arxiv.org/api/query?" + urllib.parse.urlencode({
        "search_query": query,
        "start": 0,
        "max_results": 12,
        "sortBy": "submittedDate",
        "sortOrder": "descending",
    })
    root = ET.fromstring(urllib.request.urlopen(url, timeout=60).read())
    print(f"\n### {name}")
    for entry in root.findall("a:entry", NS):
        title = " ".join(entry.find("a:title", NS).text.split())
        link = entry.find("a:id", NS).text
        published = entry.find("a:published", NS).text[:10]
        summary = " ".join(entry.find("a:summary", NS).text.split())
        print(f"{published} | {title} | {link}")
        if name == "dpwm" or "map prediction" in title.lower():
            print(summary[:1400])
