import urllib.request
import xml.etree.ElementTree as ET


IDS = "2605.05960,2512.21398,2609.37187,2603.05377,2604.02318,2610.33546,2610.25130"
URL = f"https://export.arxiv.org/api/query?id_list={IDS}&max_results=20"
NS = {"a": "http://www.w3.org/2005/Atom"}
root = ET.fromstring(urllib.request.urlopen(URL, timeout=60).read())
for entry in root.findall("a:entry", NS):
    print("###", " ".join(entry.find("a:title", NS).text.split()))
    print(entry.find("a:id", NS).text)
    print(" ".join(entry.find("a:summary", NS).text.split())[:2200])
    print()
